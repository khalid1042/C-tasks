#include<iostream>
using namespace std;

int main(){
int n ,sum;
cout<<"enter a positive integer:";
cin<=0;
cin>>n;
}
//calculate sum using formula

int sum = n*(n+1)/2;
for(int i =1;i<=n; i++){
	cout <<"sum of first"<<n<<"natural numbers:"<<sum<<endl;
return 0;
	
	
}
