#include<iostream>
using namespace std;

int main()
{
	int num;
	cout<<"enter a number:";
	
	cin>> num;
	while(num<=0){
cout <<"enter a positive integer:";
		
		cin>>num;
	}
	cout<<"multiplication table of"<<num<<":\n";
	for(int i=1;i<=10;i++){
	}
	cout<<num<<"x"<< " int i<<"="<<num*i" << "endl;
}



