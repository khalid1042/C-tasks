#include <iostream>

int calculateCube(int num) {
    return num * num * num;
}

int main() {
    int n;

cout << "Enter a positive integer: ";
    cin >> n;


    while (n <= 0) {
    cout << "Please enter a positive integer: ";
        cin >> n;
    }


    cout << "Number\tCube\n";
    for (int i = 1; i <= n; i++) {
    cout << i << "\t" << calculateCube(i) << std::endl;
    }

    return 0;
}

